# UPES Car Suspension Virtual Physics Lab

A working, presentation-style website with six sections covering all five team roles. The quarter-car numerical solver, graphs, animation, parameter studies, and deterministic physical checks work without an API key or internet connection.

## Online first (with optional live AI)

1. Upload `index.html` and `server.py` to a GitHub repository.
2. On a Python web host such as Render, create a Web Service from the repository.
3. Use start command: `python server.py` (no pip packages required).
4. In the hosting dashboard, add secret environment variable `OPENAI_API_KEY` with your own key. Do **not** paste a key into HTML or commit it to GitHub.
5. Deploy. The host will give you a public HTTPS URL. Open it and test the **AI verification** tab.
6. Optional: set `OPENAI_MODEL` to an available compatible chat-completions model.

Hosting and API usage may incur charges. The package does not publish itself or provide a hosted URL.

## Test locally before deployment

From this folder run `python server.py`, then open `http://localhost:8000`. Without a key, all physics features work and the live AI button reports that it is not configured.

## Offline version

Open `index.html` directly in Chrome, Edge, or Firefox. The numerical model, charts, animations, derivations, comparisons and local checks run entirely in your browser. Live AI requires an online server.

## Scientific notes

- Two-degree-of-freedom linear quarter-car model, displacement from static equilibrium.
- Smooth half-cosine road bump: 0.05 m between t=0.5 and 0.75 s.
- RK4 numerical integration, 0.001 s step, graph samples every 0.005 s.
- Baseline: ms=300 kg, mu=40 kg, ks=16000 N/m, cs=1200 N s/m, kt=190000 N/m.
- Reported original Python results are displayed separately and should be checked against the browser's independently computed metrics. They are not asserted to match without verification.
- Approximate body frequency and damping ratio are single-mode estimates, not the exact eigenmodes of the 2-DOF system.
- This is an educational model, not a validated automotive design tool.

## Presenting

Use the top tabs or keyboard left/right arrows. Each role has its own section. For full-screen presentation press F11 in most desktop browsers. You can print to PDF from the Report tab.
